#include "Values.h"

Values::Values()
{

}

Values::Values(double n, double w)
{
	node = n;
	weight = w;
}


Values::~Values()
{
}
