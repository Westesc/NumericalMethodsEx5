#include "horner.h"

double calculateHorner(double xValue, double factors[], int factorsLength)
{
	double result = 0.0;

	for (int i = 0; i < factorsLength; i++)
	{
		result *= xValue;
		result += factors[i];
	}

	return result;
}