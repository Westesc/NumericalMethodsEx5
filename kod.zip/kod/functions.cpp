#define _USE_MATH_DEFINES
#include <cmath>
#include <iostream>
#include <cmath>
#include "functions.h"
#include "horner.h"
using namespace std;


double fun1(double x)
{
	double y = sqrt(x*x+1);
	return y;
}


double fun2(double x)
{
	double tmp[] = { 2, 1, -2};
	double y = calculateHorner(x,tmp,3);
	return y;
}


double fun3(double x)
{
	double y = 4 * x + 1;
	return y;
}

double fun4(double x)
{
	double y = sin(x);
	return y;
}

double fun5(double x)
{
	double y = cos(2*x*x+1);
	return y;
}

bool wannaContinue()
{
	char c;
	do
	{
		cout << "Kontynuowac dzialanie programu [t/n]?";
		cin >> c;
	} while (c != 't' && c != 'n');

	cout << endl;
	if (c == 't')
		return true;
	return false;
}

double powerOf(double base, int to)
{
	if (to == 0)return 1;
	else return base *= powerOf(base, to - 1);
}

double factorial(int base)
{
	if (base == 0) return 1;
	if (base < 0) return 0;

	int result = 1;
	for (int i = 1; i <= base; i++)
	{
		result *= i;
	}
	return result;
}

double modulant(int aNumber)
{
	return 1 / (sqrt(M_PI)*powerOf(2, aNumber)*factorial(aNumber));
}

double HermitePolynomial(int i, double x)
{
	switch (i)
	{
	case 0:
		return 1;
		break;
	case 1:
		return 2 * x;
		break;
	case 2:
		return 4 * powerOf(x, 2) - 2;
		break;
	case 3:
		return 8 * powerOf(x, 3) - 12 * x;
		break;
	case 4:
		return 16 * powerOf(x, 4) - 48 * powerOf(x, 2) + 12;
		break;
	case 5:
		return 32 * powerOf(x, 5) - 160 * powerOf(x, 3) + 120 * x;
		break;
	case 6:
		return 64 * powerOf(x, 6) - 480 * powerOf(x, 4) + 720 * powerOf(x, 2) - 120;
		break;
	case 7:
		return 128 * powerOf(x, 7) - 1344 * powerOf(x, 5) + 3360 * powerOf(x, 3) - 1680 * x;
		break;
	default:
		return 1;
	}
}
