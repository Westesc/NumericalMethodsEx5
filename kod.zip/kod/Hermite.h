#pragma once
#include "Values.h"
#include <cstring>
#include <string>

using namespace std;

class Hermite
{
private:
	int howManyNodes;
public:
	double Hermite::Approximation(Values arr[4][5], double(*functions[])(double x), int g, double x, int n);
	double Hermite::Calculate(Values arr[4][5], double(*functions[])(double x), int g);
	double Hermite::CalculateA(Values arr[4][5], double(*functions[])(double x), int g, int aNumber);
	void Hermite::getArray(Values arr[4][5]);
	void Hermite::getPolynomials(double arr[8][8]);
	string Hermite::getFinalPolynomial(Values arr[4][5], double(*functions[])(double x), int g, int n);
	Hermite();
	~Hermite();
};

