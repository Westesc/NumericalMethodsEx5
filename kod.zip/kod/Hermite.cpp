#define _USE_MATH_DEFINES
#include <cmath>
#include <cstring>
#include "Hermite.h"
#include "functions.h"
#include <iostream>
#define DOKLADNOSC 0.000001

using namespace std;

Hermite::Hermite()
{
	cout << "Na ilu wezlach ma zostac obliczona calka ? [2/3/4/5] \nWybor: ";
	cin >> howManyNodes;
	cout << endl;
}


Hermite::~Hermite()
{
}

double Hermite::Calculate(Values arr[4][5], double(*functions[])(double x), int g)
{
	double(*functionPointer)(double x);
	functionPointer = functions[g];

	double result = 0, multiplier;
	for (int i = 0; i < 5; i++)
	if (arr[howManyNodes - 2][i].weight != 0)
	{
		multiplier =
			arr[howManyNodes - 2][i].weight
			*functionPointer(arr[howManyNodes - 2][i].node);
		result += multiplier;

		//cout << arr[howManyNodes - 2][i].weight << "\t" << arr[howManyNodes - 2][i].node << endl;
	}
	return result;
}

double Hermite::CalculateA(Values arr[4][5], double(*functions[])(double x), int g, int aNumber)
{
	double(*functionPointer)(double x);
	functionPointer = functions[g];

	double result = 0, multiplier;
	for (int i = 0; i < 5; i++)
	if (arr[howManyNodes - 2][i].weight != 0)
	{
		multiplier =
			arr[howManyNodes - 2][i].weight
			*functionPointer(arr[howManyNodes - 2][i].node)
			*HermitePolynomial(aNumber, arr[howManyNodes - 2][i].node);
		result += multiplier;

		//cout << arr[howManyNodes - 2][i].weight << "\t" << arr[howManyNodes - 2][i].node << endl;
	}
	return result*modulant(aNumber);
}

double Hermite::Approximation(Values arr[4][5], double(*functions[])(double x), int g, double x, int n)
{
	double result = 0;
	double factor, a, h;
	for (int i = 0; i <= n; i++)
	{
		a = CalculateA(arr, functions, g, i);
		h = HermitePolynomial(i, x);
		factor = a*h;
		result += factor;
		//cout << i << " f: " << factor << " a: " << a << " h: " << h << endl;
	}

	return result;
}

void Hermite::getArray(Values arr[4][5])
{
	for (int i = 0; i < 4; i++)
	for (int j = 0; j < 5; j++)
	{
		arr[i][j].node = 0; arr[i][j].weight = 0;
	}

	arr[0][0].node = -0.707107; arr[0][0].weight = 0.886227;
	arr[0][1].node = 0.707107;	arr[0][1].weight = 0.886227;

	arr[1][0].node = -1.224745; arr[1][0].weight = 0.295409;
	arr[1][1].node = 0.000000;	arr[1][1].weight = 1.181636;
	arr[1][2].node = 1.224745;	arr[1][2].weight = 0.295409;

	arr[2][0].node = -1.650680; arr[2][0].weight = 0.081313;
	arr[2][1].node = -0.534648; arr[2][1].weight = 0.804914;
	arr[2][2].node = 0.534648;	arr[2][2].weight = 0.804914;
	arr[2][3].node = 1.650680;	arr[2][3].weight = 0.081313;

	arr[3][0].node = -2.020183; arr[3][0].weight = 0.019953;
	arr[3][1].node = -0.958572; arr[3][1].weight = 0.393619;
	arr[3][2].node = 0.000000;	arr[3][2].weight = 0.945309;
	arr[3][3].node = 0.958572;	arr[3][3].weight = 0.393619;
	arr[3][4].node = 2.020183;	arr[3][4].weight = 0.019953;

}

void Hermite::getPolynomials(double arr[8][8])
{
	for (int i = 0; i < 8; i++)
	for (int j = 0; j < 8; j++)
	{
		arr[i][j] = 0;
	}

	arr[0][0] = 1;
	arr[1][1] = 2;
	arr[2][0] = -2;		arr[2][2] = 4;
	arr[3][1] = -12;	arr[3][3] = 8;
	arr[4][0] = 12;		arr[4][2] = -48;	arr[4][4] = 16;
	arr[5][1] = 120;	arr[5][3] = -160;	arr[5][5] = 32;
	arr[6][0] = -120;	arr[6][2] = 720;	arr[6][4] = -480;	arr[6][6] = 64;
	arr[7][1] = -1680;	arr[7][3] = 3360;	arr[7][5] = -1344;	arr[7][7] = 128;

	for (int i = 0; i < 8; i++)
	{
	cout << i << ": ";

	for (int j = 7; j >= 0; j--)
	{
	if (arr[i][j] != 0)
	cout << arr[i][j] << "x" << j << ", ";
	}
	cout << endl;
	}
}

string Hermite::getFinalPolynomial(Values arr[4][5], double(*functions[])(double x), int g, int n)
{
	double arrH[8][8];
	getPolynomials(arrH);/*
	for (int i = 0; i < 8; i++)
	for (int j = 0; j < 8; j++)
		cout << arrH[i][j] << endl;*/

	double arrFinal[8];
	for (int i = 0; i < 8; i++) arrFinal[i] = 0;

	for (int i = 0; i <= n; i++)
	{
		double a = CalculateA(arr, functions, g, i);
		//cout << "aaaa: " << a << endl;
		for (int j = 0; j <= 7; j++)
		{
			//cout << "ah:" << arrH[i][j];
			arrH[i][j] = arrH[i][j]*a;
			arrFinal[j] += arrH[i][j];
			//cout << "ah:" << arrH[i][j];
		}
	}

	//for (int i = 0; i < 8; i++) cout << " | " << arrFinal[i];

	string result;

	for (int i = 7; i >= 0; i--)
	{
		if (abs(arrFinal[i]) >= DOKLADNOSC)
		{
			if (arrFinal[i] >= 0)
				result.append(" + ");
			else
			{
				result.append(" - ");
				arrFinal[i] = -arrFinal[i];
			}

			if (i == 0)
				result.append(to_string(arrFinal[i]));
			else if (i == 1)
			{
				result.append(to_string(arrFinal[i]));
				result.append("x");
			}
			else{
				result.append(to_string(arrFinal[i]));
				result.append("x^");
				result.append(to_string(i));
			}
		}
	}

	return result;
}

