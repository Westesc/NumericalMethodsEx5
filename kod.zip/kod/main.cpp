#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <cmath>
#include <string>
#include "Values.h"
#include "functions.h"
#include "Hermite.h"
#include "gnuplot_i.hpp"

using namespace std;

int main()
{

	bool t = true;
	do{

		int a, chosenFunction, howManyNodes, level;
		double begin, end;
		cout << "Wybierz funkcje:\n"
			<< "[0] |x|\n"
			<< "[1] 2x^2 + x - 2\n"
			<< "[2] 4x+1\n"
			<< "[3] sin(x)\n"
			<< "[4] cos(2x^2+1)\n"
			<< "Wybor: ";
		cin >> chosenFunction;
		cout << endl;
		cout << "podaj poczatek zakresu: ";
		cin >> begin;
		cout << "podaj koniec zakresu: ";
		cin >> end;
		cout << "podaj ilosc wezlow: ";
		cin >> howManyNodes;
		cout << "podaj stopien wielomianu: ";
		cin >> level;

		cout << endl << endl;

		double(*functions[])(double x) = { fun1, fun2, fun3, fun4, fun5 };


		double(*functionPointer)(double x);
		functionPointer = functions[chosenFunction];

		Hermite hermite;
		Values arr[4][5];
		hermite.getArray(arr);

		cout << "Obliczony wielomian to:"<<endl;
		cout << hermite.getFinalPolynomial(arr, functions, chosenFunction, level);
		cout << endl;
		cout << "Blad aproksymacji wynosi: ";
		double epsilon = 0;
		double diff = (abs(begin - end) / (howManyNodes - 1));

		for (double i = begin; i <= end; i += diff)
		{
			epsilon += (functionPointer(i) - hermite.Approximation(arr, functions, chosenFunction, i, level))*(functionPointer(i) - hermite.Approximation(arr, functions, chosenFunction, i, level));
		}

		cout << epsilon << endl;

		//zainicjowanie sciezki gnuplota
		Gnuplot::set_GNUPlotPath("C:\gnuplot\bin");

		//zainicjowanie gnuplota
		Gnuplot main_plot;

		// ustawienie tytulu wykresu  od wybranej funkcji
		main_plot.set_title("Aproksymacja wielomianami Hermite'a");



		vector<double> baseX, baseY, resultX, resultY;
		for (double i = begin; i < end; i = i + 0.01)
		{
			baseX.push_back(i);
			baseY.push_back(functionPointer(i));
			//cout << functionPointer(i) << endl;
			resultX.push_back(i);
			resultY.push_back(hermite.Approximation(arr, functions, chosenFunction, i, level));
		}

		// ustawienie nazw osi
		main_plot.set_xlabel("x");
		main_plot.set_ylabel("f(x)");

		// ustawienie wyswietlania siatki
		main_plot.set_grid();

		// ustawienie zakresu osi x wYwietlanego wykresu
		main_plot.set_xrange(-2, 2);

		// ustawienie lines/points wykresu i wyrysowanie
		main_plot.set_style("lines");

		main_plot.plot_xy(baseX, baseY, "base");

		main_plot.plot_xy(resultX, resultY, "result");

		t = wannaContinue();
	} while (t == true);
	return 0;
}
