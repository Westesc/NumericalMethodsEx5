#pragma once

bool wannaContinue();

double fun1(double x);
double fun2(double x);
double fun3(double x);
double fun4(double x);
double fun5(double x);

double powerOf(double base, int to);
double factorial(int base);
double modulant(int aNumber);
double HermitePolynomial(int i, double x);