#pragma once
class Values
{
public:
	double node;
	double weight;
	Values();
	Values(double n, double w);
	~Values();
};

